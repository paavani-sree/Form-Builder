import json
from pathlib import Path

forms_file = Path("data/forms.json")
responses_file = Path("data/responses.json")


def create_form(form):

    forms = json.loads(forms_file.read_text())

    new_form = {
        "id": len(forms) + 1,
        "title": form.title,
        "fields": [f.dict() for f in form.fields]
    }

    forms.append(new_form)

    forms_file.write_text(json.dumps(forms, indent=2))

    return {"message": "Form created", "form": new_form}


def get_forms():

    forms = json.loads(forms_file.read_text())

    return forms


def get_form(form_id):

    forms = json.loads(forms_file.read_text())

    for f in forms:
        if f["id"] == form_id:
            return f

    return {"error": "Form not found"}


def submit_response(response):

    responses = json.loads(responses_file.read_text())

    responses.append(response)

    responses_file.write_text(json.dumps(responses, indent=2))

    return {"message": "Response saved"}