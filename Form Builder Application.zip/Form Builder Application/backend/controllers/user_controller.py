import json
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
users_file = BASE_DIR / "data" / "users.json"


def signup(user):

    users = json.loads(users_file.read_text())

    for u in users:
        if u["username"] == user.username:
            return {"message": "User already exists"}

    new_user = {
        "username": user.username,
        "password": user.password
    }

    users.append(new_user)

    users_file.write_text(json.dumps(users, indent=2))

    return {"message": "Signup successful"}


def login(user):

    users = json.loads(users_file.read_text())

    for u in users:
        if u["username"] == user.username and u["password"] == user.password:
            return {"message": "Login successful"}

    return {"message": "Invalid credentials"}