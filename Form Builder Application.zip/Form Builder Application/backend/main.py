from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from routes import user_routes

from routes import form_routes

app = FastAPI(title="Form Builder API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(user_routes.router, prefix="/users")

app.include_router(form_routes.router, prefix="/forms")

@app.get("/")
def home():
    return {"message": "Form Builder API Running"}