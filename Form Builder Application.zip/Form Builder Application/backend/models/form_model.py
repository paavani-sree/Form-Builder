from pydantic import BaseModel
from typing import List

class Field(BaseModel):
    label: str
    type: str

class Form(BaseModel):
    title: str
    fields: List[Field]