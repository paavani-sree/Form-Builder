from fastapi import APIRouter
from models.form_model import Form
from controllers import form_controller

router = APIRouter()


@router.post("/create")
def create_form(form: Form):
    return form_controller.create_form(form)


@router.get("/")
def get_forms():
    return form_controller.get_forms()


@router.get("/{form_id}")
def get_form(form_id: int):
    return form_controller.get_form(form_id)


@router.post("/submit")
def submit_response(response: dict):
    return form_controller.submit_response(response)