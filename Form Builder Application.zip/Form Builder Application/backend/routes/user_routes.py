from fastapi import APIRouter
from models.user_models import User
from controllers import user_controller

router = APIRouter()


@router.post("/signup")
def signup(user: User):
    return user_controller.signup(user)


@router.post("/login")
def login(user: User):
    return user_controller.login(user)