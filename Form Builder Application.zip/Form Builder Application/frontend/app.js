let fields = [];

function addField(){
 fields.push({label:"",type:"text"});
 renderFields();
}