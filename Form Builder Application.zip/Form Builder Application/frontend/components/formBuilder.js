function renderFields(){

 const container=document.getElementById("fields");

 container.innerHTML="";

 fields.forEach((field,index)=>{

 container.innerHTML+=`

 <div>

 <input placeholder="Field Label"
 onchange="fields[${index}].label=this.value">

 <select onchange="fields[${index}].type=this.value">

 <option value="text">Text</option>
 <option value="email">Email</option>
 <option value="number">Number</option>

 </select>

 </div>

 `;

 });

}