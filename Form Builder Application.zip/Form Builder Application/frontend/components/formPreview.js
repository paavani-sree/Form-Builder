function previewForm(){

 const preview=document.getElementById("preview");

 preview.innerHTML="";

 fields.forEach(field=>{

 preview.innerHTML+=`

 <div>

 <label>${field.label}</label>
 <input type="${field.type}">

 </div>

 `;

 });

}