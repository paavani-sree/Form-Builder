function saveForm(){

 const title=document.getElementById("title").value;

 fetch("http://127.0.0.1:8000/forms/create",{

 method:"POST",

 headers:{
 "Content-Type":"application/json"
 },

 body:JSON.stringify({
 title:title,
 fields:fields
 })

 })
 .then(res=>res.json())
 .then(data=>{
 alert("Form saved");
 });
}



