from fastapi import APIRouter, HTTPException
import json
from pathlib import Path
from jose import JWTError, jwt
from datetime import datetime, timedelta, timezone
from pydantic import BaseModel

router = APIRouter(tags=["auth"])

BASE = Path(__file__).parent / "data"
USERS = BASE / "users.json"

SECRET_KEY = "your-secret-key-change-in-production"
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30

class User(BaseModel):
    username: str
    password: str

users_data = []

def load_users():
    global users_data
    try:
        users_data = json.loads(USERS.read_text())
    except:
        users_data = []

def save_users():
    USERS.write_text(json.dumps(users_data, indent=2))

def decode_token(token: str):
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username: str = payload.get("sub")
        if username is None:
            raise HTTPException(status_code=401, detail="Invalid token")
        return username
    except (JWTError, HTTPException):
        raise HTTPException(status_code=401, detail="Invalid token")

load_users()

@router.post("/register")
async def register(user: User):
    for u in users_data:
        if u["username"] == user.username:
            raise HTTPException(status_code=400, detail="User exists")
    users_data.append({"username": user.username, "password": user.password})
    save_users()
    return {"message": "Registered"}

@router.post("/login")
async def login(user: User):
    for u in users_data:
        if u["username"] == user.username and u["password"] == user.password:
            access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
            to_encode = {"sub": user.username}
            expire = datetime.utcnow() + access_token_expires
            to_encode.update({"exp": expire})
            access_token = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
            return {"access_token": access_token, "token_type": "bearer", "username": user.username}
    raise HTTPException(status_code=400, detail="Invalid login")
