from fastapi import APIRouter, HTTPException, Depends
import json
from pathlib import Path
from auth import decode_token
from fastapi import Header

router = APIRouter()

FORMS_FILE = Path(__file__).parent / "data/forms.json"
forms_data = []

def load_forms():
    global forms_data
    try:
        forms_data = json.loads(FORMS_FILE.read_text())
    except:
        forms_data = []

def save_forms():
    FORMS_FILE.write_text(json.dumps(forms_data, indent=2))

load_forms()

async def get_current_user(authorization: str = Header(None)):
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Not authenticated")
    token = authorization.split(" ")[1]
    return decode_token(token)

@router.get("/forms")
async def get_forms(current_user: str = Depends(get_current_user)):
    user_forms = [f for f in forms_data if f.get("owner") == current_user]
    return user_forms

@router.post("/forms")
async def create_form(form: dict, current_user: str = Depends(get_current_user)):
    form["id"] = len([f for f in forms_data if f.get("owner") == current_user]) + 1
    form["owner"] = current_user
    forms_data.append(form)
    save_forms()
    return {"message": "Form created", "form": form}

@router.put("/forms/{form_id}")
async def update_form(form_id: int, form: dict, current_user: str = Depends(get_current_user)):
    for i, f in enumerate(forms_data):
        if f["id"] == form_id and f["owner"] == current_user:
            forms_data[i]["title"] = form.get("title", f["title"])
            forms_data[i]["questions"] = form.get("questions", f["questions"])
            save_forms()
            return {"message": "Form updated"}
    raise HTTPException(status_code=404, detail="Form not found")

@router.delete("/forms/{form_id}")
async def delete_form(form_id: int, current_user: str = Depends(get_current_user)):
    global forms_data
    original_len = len(forms_data)
    forms_data = [f for f in forms_data if not (f["id"] == form_id and f["owner"] == current_user)]
    if len(forms_data) < original_len:
        save_forms()
        return {"message": "Form deleted"}
    raise HTTPException(status_code=404, detail="Form not found")
