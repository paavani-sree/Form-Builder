from fastapi import FastAPI, Depends, Header
from fastapi.middleware.cors import CORSMiddleware
import auth
import forms
import responses

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router)
app.include_router(forms.router)
app.include_router(responses.router)

@app.get("/")
async def home():
    return {"message": "API Running"}

@app.get("/decode-token")
async def decode_token_endpoint(authorization: str = Header(None)):
    if not authorization or not authorization.startswith("Bearer "):
        return {"error": "No token"}
    token = authorization.split(" ")[1]
    try:
        username = decode_token(token)
        return {"username": username}
    except:
        return {"error": "Invalid token"}
