from fastapi import APIRouter, Depends
from fastapi.responses import StreamingResponse
import json
from pathlib import Path
import csv
import io
from typing import List
from auth import decode_token
from fastapi import Header
from fastapi import HTTPException

async def get_current_user(authorization: str = Header(None)):
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Not authenticated")
    token = authorization.split(" ")[1]
    return decode_token(token)

router = APIRouter()

BASE = Path(__file__).parent / "data"
RESP = BASE / "responses.json"

responses_data = []

def load_responses():
    global responses_data
    try:
        responses_data = json.loads(RESP.read_text())
    except:
        responses_data = []

def save_responses():
    RESP.write_text(json.dumps(responses_data, indent=2))

load_responses()

@router.post("/responses")
async def submit(resp: dict):
    responses_data.append(resp)
    save_responses()
    return {"message": "Saved"}

@router.get("/responses/{form_id}")
async def get_responses(form_id: int, current_user: str = Depends(get_current_user)):
    user_responses = [r for r in responses_data if r.get("form_id") == form_id]
    return user_responses

@router.get("/responses/{form_id}/export/csv")
async def export_csv(form_id: int, current_user: str = Depends(get_current_user)):
    user_responses = [r for r in responses_data if r.get("form_id") == form_id]
    
    output = io.StringIO()
    writer = csv.DictWriter(output, fieldnames=["form_id", "answers"])
    writer.writeheader()
    writer.writerows(user_responses)
    
    return StreamingResponse(
        iter([output.getvalue()]),
        media_type="text/csv",
        headers={"Content-Disposition": f"attachment; filename=responses_{form_id}.csv"}
    )
