// Global API helper with token
const API_BASE = "http://127.0.0.1:8000";

async function apiCall(endpoint, options = {}) {
  const token = localStorage.getItem("token");
  const headers = {
    "Content-Type": "application/json",
    ...options.headers,
  };
  if (token) {
    headers["Authorization"] = `Bearer ${token}`;
  }
  const res = await fetch(`${API_BASE}${endpoint}`, {
    ...options,
    headers,
  });
  return res.json();
}

// Login
const loginBtn = document.getElementById("loginBtn") || document.querySelector("button[onclick='login()']");
const usernameInput = document.getElementById("username");
const passwordInput = document.getElementById("password");

async function login() {
  try {
    const data = await apiCall("/login", {
      method: "POST",
      body: JSON.stringify({
        username: usernameInput.value,
        password: passwordInput.value
      })
    });
    if (data.access_token) {
      localStorage.setItem("token", data.access_token);
      localStorage.setItem("username", data.username);
      window.location.href = "dashboard.html";
    } else {
      showMessage("Invalid login", "error");
    }
  } catch (err) {
    showMessage("Login failed", "error");
  }
}

// Register
async function register() {
  try {
    const data = await apiCall("/register", {
      method: "POST",
      body: JSON.stringify({
        username: usernameInput.value,
        password: passwordInput.value
      })
    });
    showMessage(data.message || "Registered", "success");
  } catch (err) {
    showMessage("Registration failed", "error");
  }
}

// Auth check for protected pages
function checkAuth() {
  const token = localStorage.getItem("token");
  if (!token) {
    window.location.href = "index.html";
  }
}

// Utility
function showMessage(msg, type) {
  const msgDiv = document.getElementById("message") || createMessageDiv();
  msgDiv.textContent = msg;
  msgDiv.className = type;
}

function createMessageDiv() {
  const div = document.createElement("div");
  div.id = "message";
  div.style.marginTop = "10px";
  document.body.appendChild(div);
  return div;
}

// Logout
function logout() {
  localStorage.removeItem("token");
  localStorage.removeItem("username");
  window.location.href = "index.html";
}

// Run auth check if not index.html
if (!window.location.pathname.includes("index.html")) {
  checkAuth();
}
