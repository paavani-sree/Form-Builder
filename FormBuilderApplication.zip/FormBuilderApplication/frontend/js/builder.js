let questions = [];
let draggedIndex = -1;

document.addEventListener('DOMContentLoaded', () => {
  checkAuth();
  const urlParams = new URLSearchParams(window.location.search);
  const editId = urlParams.get('id');
  if (editId) {
    loadFormForEdit(editId);
  }
});

function addQuestion() {
  questions.push({
    id: Date.now(),
    label: '',
    type: 'short',
    required: false,
    options: []
  });
  renderQuestions();
}

function renderQuestions() {
  const container = document.getElementById('questionsContainer');
  container.innerHTML = '';
  questions.forEach((q, index) => {
    const qDiv = document.createElement('div');
    qDiv.className = 'question';
    qDiv.draggable = true;
    qDiv.dataset.index = index;
    qDiv.ondragstart = () => draggedIndex = index;
    qDiv.ondragover = e => e.preventDefault();
    qDiv.ondrop = () => reorderQuestions(draggedIndex, index);
    qDiv.innerHTML = `
      <div class="drag-handle">⋮⋮</div>
      <input placeholder="Question label" value="${q.label}" onchange="updateQuestion(${index}, 'label', this.value)">
      <select onchange="updateQuestion(${index}, 'type', this.value)">
        <option value="short" ${q.type === 'short' ? 'selected' : ''}>Short answer</option>
        <option value="paragraph" ${q.type === 'paragraph' ? 'selected' : ''}>Paragraph</option>
        <option value="mcq" ${q.type === 'mcq' ? 'selected' : ''}>Multiple choice</option>
        <option value="checkbox" ${q.type === 'checkbox' ? 'selected' : ''}>Checkboxes</option>
        <option value="dropdown" ${q.type === 'dropdown' ? 'selected' : ''}>Dropdown</option>
        <option value="rating" ${q.type === 'rating' ? 'selected' : ''}>Linear scale</option>
        <option value="file" ${q.type === 'file' ? 'selected' : ''}>File upload</option>
      </select>
      <label>
        <input type="checkbox" ${q.required ? 'checked' : ''} onchange="updateQuestion(${index}, 'required', this.checked)"> Required
      </label>
      ${q.type === 'mcq' || q.type === 'checkbox' || q.type === 'dropdown' ? `
        <div>
          <button onclick="addOption(${index})">Add option</button>
          <div>
            ${q.options.map((opt, optIndex) => `
              <input placeholder="Option" value="${opt}" onchange="updateOption(${index}, ${optIndex}, this.value)">
            `).join('')}
          </div>
        </div>
      ` : ''}
      <button onclick="deleteQuestion(${index})" class="btn-danger">Delete</button>
    `;
    container.appendChild(qDiv);
  });
}

function updateQuestion(index, field, value) {
  questions[index][field] = value;
}

function addOption(index) {
  questions[index].options.push('');
  renderQuestions();
}

function updateOption(qIndex, optIndex, value) {
  questions[qIndex].options[optIndex] = value;
}

function deleteQuestion(index) {
  questions.splice(index, 1);
  renderQuestions();
}

function reorderQuestions(fromIndex, toIndex) {
  const [moved] = questions.splice(fromIndex, 1);
  questions.splice(toIndex, 0, moved);
  renderQuestions();
}

async function saveForm() {
  if (!questions.length || !document.getElementById('formTitle').value) {
    showMessage('Add title and questions', 'error');
    return;
  }
  try {
    const formData = {
      title: document.getElementById('formTitle').value,
      questions: questions
    };
    const urlParams = new URLSearchParams(window.location.search);
    const editId = urlParams.get('id');
    if (editId) {
      await apiCall(`/forms/${editId}`, {method: 'PUT', body: JSON.stringify(formData)});
    } else {
      await apiCall('/forms', {method: 'POST', body: JSON.stringify(formData)});
    }
    showMessage('Form saved!', 'success');
    setTimeout(() => window.location.href = 'dashboard.html', 1000);
  } catch (err) {
    showMessage('Save failed', 'error');
  }
}

function previewForm() {
  const title = document.getElementById('formTitle').value;
  const params = new URLSearchParams({title: title, questions: JSON.stringify(questions)});
  window.open(`preview.html?${params.toString()}`, '_blank');
}

function cancel() {
  window.location.href = 'dashboard.html';
}

async function loadFormForEdit(id) {
  try {
    const forms = await apiCall('/forms');
    const form = forms.find(f => f.id == id);
    if (form) {
      document.getElementById('formTitle').value = form.title;
      questions = form.questions.map(q => ({...q, id: Date.now()}));
      renderQuestions();
    }
  } catch (err) {
    showMessage('Form not found', 'error');
  }
}
