// Load forms on page load
document.addEventListener('DOMContentLoaded', async () => {
  const username = localStorage.getItem('username') || 'User';
  document.getElementById('userGreeting').textContent = `Welcome back, ${username}!`;
  await loadForms();
});

let allForms = [];
let allResponseCounts = [];

async function loadForms() {
  console.log('Dashboard loadForms started');
  const token = localStorage.getItem('token');
  console.log('Token exists:', !!token);
  try {
    const forms = await apiCall('/forms');
    console.log('Forms loaded:', forms);
    
    if (!Array.isArray(forms)) {
      throw new Error('API did not return an array');
    }
    
    allForms = forms;
    updateStats();
    
    if (forms.length === 0) {
      document.getElementById('forms').innerHTML = '<p class="card" style="text-align:center; padding:40px; color:#666;">No forms found. <button onclick="createForm()" class="btn-success">Create your first form</button></p>';
      return;
    }
    
    // Pre-fetch all response counts
    const responsePromises = forms.map(form => getResponseCount(form.id));
    allResponseCounts = await Promise.all(responsePromises);
    renderForms(forms);
  } catch (err) {
    console.error('Load forms error:', err);
    let msg = 'Failed to load forms';
    if (err.status === 401) msg = 'Please login again';
    else if (err.message) msg += ': ' + err.message;
    document.getElementById('forms').innerHTML = `<p class="error card" style="text-align:center; padding:20px;">${msg}. Check console/server.</p>`;
  }
}

async function getResponseCount(formId) {
  try {
    const responses = await apiCall(`/responses/${formId}`);
    return Array.isArray(responses) ? responses.length : 0;
  } catch {
    return 0;
  }
}

function renderForms(formsToRender) {
  const container = document.getElementById('forms');
  container.innerHTML = '';
  
  formsToRender.forEach((form, index) => {
    const fullIndex = allForms.indexOf(form);
    const count = allResponseCounts[fullIndex] || 0;
    const card = document.createElement('div');
    card.className = 'form-card';
    card.innerHTML = `
      <div style="flex:1;">
        <h3>${form.title || 'Untitled'}</h3>
        <p>Responses: <strong>${count}</strong> | ID: ${form.id} | Owner: ${form.owner || 'N/A'}</p>
      </div>
      <div style="display:flex; gap:5px;">
        <button onclick="openForm(${form.id})" class="btn-success">Fill</button>
        <button onclick="viewResponses(${form.id})">View Responses</button>
        <button onclick="deleteForm(${form.id})" class="btn-danger">Delete</button>
      </div>
    `;
    container.appendChild(card);
  });
}

function filterForms() {
  const query = document.getElementById('searchInput').value.toLowerCase();
  const filtered = allForms.filter(f => f.title.toLowerCase().includes(query));
  renderForms(filtered);
}

function updateStats() {
  document.getElementById('totalForms').textContent = allForms.length;
  let totalResp = 0;
  allResponseCounts.forEach(c => totalResp += c);
  document.getElementById('totalResponses').textContent = totalResp;
}

function openForm(id) {
  window.location.href = `fill-form.html?id=${id}`;
}

function viewResponses(id) {
  window.location.href = `responses.html?formId=${id}`;
}

async function deleteForm(id) {
  if (!confirm('Delete this form?')) return;
  try {
    await apiCall(`/forms/${id}`, {method: 'DELETE'});
    loadForms();
    showMessage('Form deleted successfully!', 'success');
  } catch (err) {
    showMessage('Delete failed', 'error');
  }
}

function createForm() {
  window.location.href = 'builder.html';
}

// Logout
document.getElementById('logout').onclick = logout;

