document.addEventListener('DOMContentLoaded', loadForm);

async function loadForm() {
  const params = new URLSearchParams(window.location.search);
  const id = params.get('id');
  if (!id) {
    document.body.innerHTML = '<h2>Invalid form ID</h2>';
    return;
  }

  try {
    const forms = await apiCall('/forms');
    const form = forms.find(f => f.id == id);
    if (!form) {
      document.body.innerHTML = '<h2>Form not found</h2>';
      return;
    }

    document.getElementById('formTitle').textContent = form.title;
    const container = document.getElementById('formContainer');
    form.questions.forEach(q => {
      const qDiv = document.createElement('div');
      qDiv.className = 'question';
      const required = q.required ? ' class="required"' : '';
      let inputHtml = '';
      let name = q.label.replace(/[^a-zA-Z0-9]/g, '_');
      switch (q.type) {
        case 'paragraph':
          inputHtml = `<textarea name="${name}" ${q.required ? 'required' : ''} placeholder="${q.label}"></textarea>`;
          break;
        case 'mcq':
          inputHtml = q.options.map((opt, i) => 
            `<label class="option-group"><input type="radio" name="${name}" value="${opt}" ${q.required ? 'required' : ''}> ${opt}</label>`
          ).join('');
          break;
        case 'checkbox':
          inputHtml = q.options.map(opt => 
            `<label class="option-group"><input type="checkbox" name="${name}" value="${opt}"> ${opt}</label>`
          ).join('');
          break;
        case 'dropdown':
          inputHtml = `<select name="${name}" ${q.required ? 'required' : ''}>
            <option value="">Select...</option>
            ${q.options.map(opt => `<option>${opt}</option>`).join('')}
          </select>`;
          break;
        case 'rating':
          inputHtml = `<input type="range" name="${name}" min="1" max="10" ${q.required ? 'required' : ''}>`;
          break;
        case 'file':
          inputHtml = `<input type="file" name="${name}">`;
          break;
        default:
          inputHtml = `<input name="${name}" ${q.required ? 'required' : ''} placeholder="${q.label}">`;
      }
      qDiv.innerHTML = `<label${required}>${q.label}</label>${inputHtml}`;
      container.appendChild(qDiv);
    });
  } catch (err) {
    showMessage('Failed to load form', 'error');
  }
}

async function submitForm() {
  const formData = new FormData(document.getElementById('fillForm'));
  const params = new URLSearchParams(window.location.search);
  const id = params.get('id');
  
  const answers = {};
  for (let [key, value] of formData.entries()) {
    if (answers[key]) {
      if (!Array.isArray(answers[key])) answers[key] = [answers[key]];
      answers[key].push(value);
    } else {
      answers[key] = value;
    }
  }

  try {
    await apiCall(`/responses`, {
      method: 'POST',
      body: JSON.stringify({form_id: parseInt(id), answers})
    });
    showMessage('Form submitted successfully!', 'success');
    setTimeout(() => {
      document.getElementById('fillForm').reset();
    }, 2000);
  } catch (err) {
    showMessage('Submission failed', 'error');
  }
}
