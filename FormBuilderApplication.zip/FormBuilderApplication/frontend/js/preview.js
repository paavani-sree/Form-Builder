document.addEventListener('DOMContentLoaded', loadPreview);

function loadPreview() {
  const urlParams = new URLSearchParams(window.location.search);
  const title = urlParams.get('title') || 'Preview';
  const questionsStr = urlParams.get('questions');
  document.getElementById('previewTitle').textContent = title;
  
  let questions = [];
  if (questionsStr) {
    questions = JSON.parse(decodeURIComponent(questionsStr));
  }
  
  const container = document.getElementById('previewQuestions');
  questions.forEach(q => {
    const qDiv = document.createElement('div');
    qDiv.className = 'preview-question';
    const required = q.required ? ' class="required"' : '';
    let inputHtml = '';
    switch (q.type) {
      case 'paragraph':
        inputHtml = '<textarea disabled placeholder="' + q.label + '"></textarea>';
        break;
      case 'mcq':
        inputHtml = q.options.map(opt => `<label><input type="radio" disabled> ${opt}</label>`).join('');
        break;
      case 'checkbox':
        inputHtml = q.options.map(opt => `<label class="option-group"><input type="checkbox" disabled> ${opt}</label>`).join('');
        break;
      case 'dropdown':
        inputHtml = `<select disabled><option>${q.options.join('</option><option>')}</option></select>`;
        break;
      case 'rating':
        inputHtml = '<input type="range" min="1" max="10" disabled>';
        break;
      case 'file':
        inputHtml = '<input type="file" disabled>';
        break;
      default:
        inputHtml = '<input disabled placeholder="' + q.label + '">';
    }
    qDiv.innerHTML = `<label${required}>${q.label}</label>${inputHtml}`;
    container.appendChild(qDiv);
  });
}
