document.addEventListener('DOMContentLoaded', loadResponses);

async function loadResponses() {
  const params = new URLSearchParams(window.location.search);
  const formId = params.get('formId');
  if (!formId) {
    document.body.innerHTML = '<h2>No form ID</h2>';
    return;
  }

  try {
    const responses = await apiCall(`/responses/${formId}`);
    document.getElementById('responsesTitle').textContent = `Responses for Form ${formId} (${responses.length})`;
    
    if (responses.length === 0) {
      document.getElementById('responsesTable').innerHTML = '<p>No responses yet.</p>';
      return;
    }

    const table = createTable(responses);
    document.getElementById('responsesTable').appendChild(table);
  } catch (err) {
    showMessage('Failed to load responses', 'error');
  }
}

function createTable(responses) {
  const table = document.createElement('table');
  table.style.width = '100%';
  table.style.borderCollapse = 'collapse';
  
  // Header
  const thead = document.createElement('thead');
  thead.innerHTML = '<tr><th>Response ID</th><th>Answers</th></tr>';
  table.appendChild(thead);
  
  // Rows
  const tbody = document.createElement('tbody');
  responses.forEach((response, index) => {
    const row = document.createElement('tr');
    row.innerHTML = `
      <td>${index + 1}</td>
      <td>
        <pre>${JSON.stringify(response.answers, null, 2)}</pre>
      </td>
    `;
    tbody.appendChild(row);
  });
  table.appendChild(tbody);
  
  return table;
}

async function exportCSV() {
  const params = new URLSearchParams(window.location.search);
  const formId = params.get('formId');
  const link = document.createElement('a');
  link.href = `${API_BASE}/responses/${formId}/export/csv`;
  link.download = `responses_${formId}.csv`;
  link.click();
}

function backToDashboard() {
  window.location.href = 'dashboard.html';
}
